import mysql.connector
from pprint import pprint
mydb = mysql.connector.connect(host="localhost",user="root",passwd="angelbmona@N1",database='snapbuy')
cursor = mydb.cursor()
userlist = ["Mahir","Naman"]
userpasswd = ["263","266"]
cnt = 100
def userlogin(a,b):
    if a in userlist:
        j = 0
        for i in range(2):
            if userlist[i]==a:
                j = i
                break
        if (userpasswd[j]==b):
            print("Welcome to the snapbuy online retail store"+" "+a)
            return True
        else:
            print("Invaild")
            return False
    else:
        print("Invalid")
def viewproduct():
    cursor.execute(f"select * from PRODUCT")
    data = cursor.fetchall()
    if (len(data)>0):
        for i in range(len(data)):
            print(data[i])
    else:
        print("No Row Affected")
def viewpro(a):
    cursor.execute(f"select * from PRODUCT where PRODUCT_ID = '{a}' ")
    data = cursor.fetchall()
    if (len(data)>0):
        for i in range(len(data)):
            print(data[i])
    else:
        print("No Row Affected")
def viewcar(a):
    cursor.execute(f"select * from CART where PRODUCT_ID = '{a}' ")
    data = cursor.fetchall()
    if (len(data)>0):
        for i in range(len(data)):
            print(data[i])
    else:
        print("No Row Affected")
def viewUSER():
    cursor.execute(f"select * from USR limit 10")
    data = cursor.fetchall()
    if (len(data)>0):
        for i in range(len(data)):
            print(data[i])
    else:
        print("No Row Affected")
def changeproductprice(a,b):
    cursor.execute(f"UPDATE PRODUCT SET PRODUCT_COST= '{b}' WHERE PRODUCT_ID = '{a}'")
    print("Updated succesfully")
    cursor.execute(f"select * from PRODUCT where PRODUCT_ID = '{a}'")
    data = cursor.fetchall()
    if (len(data)>0):
        for i in range(len(data)):
            print(data[i])
    else:
        print("No Row Affected")
def viewShipper(a):
    cursor.execute(f"SELECT * FROM SHIPPER WHERE SHIPPER_ID = ANY(SELECT SHIPPER_ID FROM ORDE WHERE USER_ID = '{a}')")
    data = cursor.fetchall()
    if (len(data)>0):
        for i in range(len(data)):
            print(data[i])
    else:
        print("No Row Affected")
def changefeedbackrating(a,b):
    cursor.execute(f"UPDATE FEEDBACK SET FEEDBACK_RATING= FEEDBACK_RATING + '{b}' WHERE USER_ID = '{a}'")
    print("Updated succesfully")
    cursor.execute(f"select * from PRODUCT where PRODUCT_ID = '{a}'")
    data = cursor.fetchall()
    if (len(data)>0):
        for i in range(len(data)):
            print(data[i])
    else:
        print("No Row Affected")
def viewfeedback(a):
    cursor.execute(f"SELECT * FROM FEEDBACK WHERE USER_ID = '{a}'")
    data = cursor.fetchall()
    if (len(data)>0):
        for i in range(len(data)):
            print(data[i])
    else:
        print("No Row Affected")
def olap1():
    cursor.execute(f"select Product_Cost, Produt_Rating from Product group by Product_Cost, Produt_Rating with rollup limit 10")
    data = cursor.fetchall()
    if (len(data)>0):
        for i in range(len(data)):
            print(data[i])
    else:
        print("No Row Affected")
def olap2():
    cursor.execute(f"select shipper_rating,Total_Cost, count(*) from orde, shipper where orde.shipper_id = shipper.shipper_id group by shipper_rating, Total_Cost with rollup limit 30")
    data = cursor.fetchall()
    if (len(data)>0):
        for i in range(len(data)):
            print(data[i])
    else:
        print("No Row Affected")
def olap3():
    cursor.execute(f"select feedback_rating,Product_Cost, count(*) from product inner join feedback group by feedback_rating, Product_Cost with rollup limit 50")
    data = cursor.fetchall()
    if (len(data)>0):
        for i in range(len(data)):
            print(data[i])
    else:
        print("No Row Affected")
def olap4():
    cursor.execute(f"select coupon_discount,Product_Cost, count(*) from product inner join coupon group by coupon_discount, Product_Cost with rollup having coupon_discount = 4")
    data = cursor.fetchall()
    if (len(data)>0):
        for i in range(len(data)):
            print(data[i])
    else:
        print("No Row Affected")
def getprimeuser():
    cursor.execute(f"SELECT USER_NAME, COUNT(*) FROM USR INNER JOIN CART ON USR.USER_ID = CART.USER_ID WHERE CART.PRICE > 8000 GROUP BY USER_NAME ORDER BY USER_NAME")
    data = cursor.fetchall()
    if (len(data)>0):
        for i in range(len(data)):
            print(data[i])
    else:
        print("No Row Affected")
def get5starproducts():
    cursor.execute(f"SELECT PRODUCT_COST, COUNT(*) FROM PRODUCT WHERE PRODUT_RATING =5 GROUP BY PRODUCT_COST ORDER BY PRODUCT_COST DESC")
    data = cursor.fetchall()
    if (len(data)>0):
        for i in range(len(data)):
            print(data[i])
    else:
        print("No Row Affected")
def getCartofUser(a):
    cursor.execute(f"SELECT * FROM CART WHERE USER_ID = '{a}' ")
    data = cursor.fetchall()
    if (len(data)>0):
        print("PRODUCT_ID ||  USER_ID || QUANTITY || PRICE")
        for i in range(len(data)):
            pprint(data[i])
    else:
        print("Cart is Empty")
def addtoCart(a,b,x,y):
    cursor.execute(f"INSERT INTO CART (Product_Id,User_Id,Quantity,Price) VALUES ({b},{a},{x},{y})")
    data = cursor.fetchall()
    print("Succesfully Added to Cart")
def deletefromCart(a):
    cursor.execute(f"DELETE FROM CART WHERE USER_ID = '{a}'")
    data = cursor.fetchall()
    print("Succesfully Cleared to Cart")
def updateinventory(a,b):
    cursor.execute(f"UPDATE INVENTORY SET QUANTITY = QUANTITY + '{b}' WHERE PRODUCT_ID = '{a}'")
    mydb.commit()
    data = cursor.fetchall()
    if (len(data)>0):
        for i in range(len(data)):
            print(data[i])
    else:
        print("No Row Affected")
def getdiscount(a):
    cursor.execute(f"SELECT MAX(COUPON_DISCOUNT) FROM COUPON WHERE USER_ID = '{a}' AND COUPON_EXPIRYDATE >= '01-01-2024'")
    data = cursor.fetchall()
    return data
def addBill(cnt,b,c):
    cursor.execute(f"INSERT INTO BILL VALUES ({cnt},'{b}','{c}')")
    mydb.commit()
    cnt+=1
    data = cursor.fetchall()
    if (len(data) > 0):
        return cnt-1
    else:
        print("No row affected")
def addShipper(cnt,b,c,d):
    cursor.execute(f"INSERT INTO SHIPPER VALUES ({cnt},'{b}','{c}',{d})")
    mydb.commit()
    cnt+=1
    data = cursor.fetchall()
    if (len(data) > 0):
        return cnt-1
    else:
        print("No row affected")
def addCoupon(cnt,a):
    g=5
    b=1
    cursor.execute(f"INSERT INTO COUPON VALUES({cnt},{g},{'01-01-2023'},{b},{a})")
    mydb.commit()
    cnt+=1
    data = cursor.fetchall()
    if (len(data)>0):
        return cnt-1
    else:
        print("No row affected")
def addOrder(cnt,b,c,totalcost,coupon,dbill,usid):
    #print(str(cnt)+ " " + str(b) + " "+ str(c) + " " + str(totalcost)+ " "+ str(coupon) + " " + str(dbill) + " "+str(usid))
    cursor.execute(f"INSERT INTO ORDE VALUES ({cnt},'{b}',{c},{totalcost},{coupon},{dbill},{usid})")
    mydb.commit()
    cnt+=1
    data = cursor.fetchall()
    if (len(data) > 0):
        return cnt-1
    else:
        print("No row affected")
def checkout(a):
    print("Thanks User for Buying from SnapBuy. We are always here to Serve You.")
    total_cost = 0
    cursor.execute(f"SELECT * FROM CART WHERE USER_ID = '{a}' ")
    data = cursor.fetchall()
    for i in range(len(data)):
        updateinventory(data[i][0],data[i][2])
    for j in range(len(data)):
        total_cost+= data[j][2]*data[j][3]
    cnt = 1000
    print("Your Final Cost for the Order is: ",total_cost)
    l1 = getdiscount(a)
    print("Total Discount You received is: ", l1[0][0])
    print("So the final price you need to pay is ",total_cost - l1[0][0]*0.01*total_cost)
    print("Congratulations Your Payment has been processed and You have now become an Elite member of SnapBuy")
    deletefromCart(a)
    cursor.execute(f"SELECT STREET,CITY FROM USR WHERE USER_ID = '{a}' ")
    data1 = cursor.fetchall()
    #print()
    l2 =addBill(cnt,str(data1[0][0]+data1[0][1]),"Online")
    cursor.execute(f"SELECT SHIPPER_NAME,SHIPPER_RATING,SHIPPER_ADDRESS FROM SHIPPER WHERE SHIPPER_RATING=0")
    data2 = cursor.fetchall()
    l3 =addShipper(cnt+1,data2[0][0],data2[0][2],data2[0][1])
    print("Congratulations you have also won A coupon")
    l4 =addCoupon(cnt+3,a)
    print("Your Order Along with Shipper Id and Coupon Id and Total Cost is placed")
    cursor.execute(f"SELECT STREET,CITY FROM USR WHERE USER_ID = '{a}'")
    data5 = cursor.fetchall()
    #print(data5)
    l5 =addOrder(cnt+2,str(data5[0][0]),cnt+1,int(total_cost),cnt+3,cnt,a)
    print("Your Order id is: ",cnt+2)
    print("Your Cart is Now Empty. Hurry and fill it Again")
    mydb.commit()
def getorder(a):
    cursor.execute(f"SELECT * FROM ORDE WHERE ORDER_ID = '{a}' ")
    data = cursor.fetchall()
    if (len(data)>0):
        print("PRODUCT_ID ||  USER_ID || QUANTITY || PRICE")
        for i in range(len(data)):
            pprint(data[i])
    else:
        print("No order is found")
def deleteorder(a):
    cursor.execute(f"DELETE FROM ORDE WHERE ORDER_ID = '{a}' ")
    mydb.commit()
    data = cursor.fetchall()
    if (len(data)>0):
        print("PRODUCT_ID ||  USER_ID || QUANTITY || PRICE")
        for i in range(len(data)):
            pprint(data[i])
    else:
        print("No order is found")
def givefeeback(a,b,c):
    deleteorder(a)
    cursor.execute(f"INSERT INTO FEEDBACK VALUES ({a},{a},'{c}',{b})")
    mydb.commit()
    print("Thank you for giving the Feedback..")
    data = cursor.fetchall()
    if (len(data)>0):
        return
    else:
        print("No Row Affected")
a = input("Enter username")
b = input("Enter password")
if (userlogin(a,b)):
    cnt = 0
    print("1.ViewProduct")
    print("2.Changeproductprice")
    print("3.ViewFeedback")
    print("4.ViewShipperRating")
    print("5.Changefeedbackrating")
    print("6.ViewaParticularProduct")
    print("7:To view the cart")
    print("8.For the hierarchy of Products on the basis of rating cost and name")
    print("9.For finding hierarchy of shipper ratings and total cost of an order of all the orders placed")
    print("10.For finding hierarchy of feedback ratings and product cost of all products in the inventory")
    print("11.For finding hierarchy of coupon discount and product cost of all products in the inventory here specifically coupon discount is 4%")
    print("12. For getting the prime users")
    print("13. For getting all 5 star products")
    print("14: For Checking Cart")
    print("15: Add product to Cart")
    print("16: For Clearing the Cart")
    print("17: For updating the inventory")
    print("18: For getting the max- discount available to you")
    print("19: For checkout the cart")
    print("20: For getting information about order")
    print("21: For giving the feedback")
    while (cnt!=-1):
        cnt = int(input())
        if (cnt==1):
            viewproduct()
        if (cnt==2):
            x = int(input("Enter new price of product: "))
            y = int(input("Enter product ID: "))
            print("Here is the change made to the database")
            changeproductprice(y,x)
        if (cnt==3):
            x = int(input("Enter user id to view the feedback"))
            viewfeedback(x)
        if (cnt==4):
            x = int(input("Enter user id whose order is being carried: "))
            viewShipper(x)
        if (cnt==5):
            x = int(input("Enter the user id of the feedback"))
            y = int(input("Enter the amount by which feedback has to be changed"))
            changefeedbackrating(x,y)
        if (cnt==6):
            x = int(input("Enter the product ID :"))
            viewpro(x)
        if (cnt==7):
            x = int(input("Enter the product ID"))
            viewcar(x)
        if (cnt==8):
            olap1()
        if (cnt==9):
            olap2()
        if (cnt==10):
            olap3()
        if (cnt==11):
            olap4()
        if (cnt==12):
            getprimeuser()
        if (cnt==13):
            get5starproducts()
        if (cnt==14):
            x = int(input("Enter the User_ID: "))
            getCartofUser(x)
        if (cnt==15):
            x = int(input("Enter the User_ID: "))
            y = int(input("Enter the Product_ID: "))
            z = int(input("Enter the Quantity: "))
            w = int(input("Enter the Price: "))
            addtoCart(x,y,z,w)
        if (cnt==16):
            x = int(input("Enter the User_ID: "))
            deletefromCart(x)
        if (cnt==17):
            y = int(input("Enter the Product_ID: "))
            z = int(input("Enter the Quantity: "))
            updateinventory(y,z)
        if (cnt==18):
            x = int(input("Enter the User_ID: "))
            l2 = getdiscount(x)
            print(l2[0])
        if (cnt==19):
            x = int(input("Enter the User_ID: "))
            checkout(x)
        if (cnt==20):
            x = int(input("Enter the Order_ID: "))
            getorder(x)


        
        

        




    
    

